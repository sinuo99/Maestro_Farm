from microbit import *
import math

# Tilt microbit to fill up all the LEDs to allow microbit to calibrate
compass.calibrate()

# Define a function to send button 'DistanceDialer' message
def midiNoteOn(chan, n, vel):
    MIDI_NOTE_ON = 0x90
    if chan > 15:
        return
    if n > 127:
        return
    if vel > 127:
        return
    msg = bytes([MIDI_NOTE_ON | chan, n, vel])
    uart.write(msg)


# Define a function to send button 'A' and 'B', campass, yaccelerometer messages
def midiControlChange(chan, n, value):
    MIDI_CC = 0xB0
    if chan > 15:
        return
    if n > 127:
        return
    if value > 127:
        return
    msg = bytes([MIDI_CC | chan, n, value])
    uart.write(msg)


def Start():
    uart.init(baudrate=31250, bits=8, parity=None, stop=1, tx=pin0)


Start()
# Initialise the compass variables
current_orien = 0
locate = 0
panning = 0
# Initialise the yaccelerometer variables
Strigger = 0

while True:
    # Access yaccelerometer data three times
    y1 = accelerometer.get_y()
    y2 = accelerometer.get_y()
    y3 = accelerometer.get_y()
    # Sum-up yaccelerometer data and take the average value to filter the output
    current_y = math.floor((y1 + y2 + y3) / 3)

    # Access compass data when the microbit is being held horizontally
    if -80 < current_y < 200:
        # Access compass data three times
        c1 = compass.heading()
        c2 = compass.heading()
        c3 = compass.heading()
        # Sum-up compass data and take the average value to filter the output
        current_orien = math.floor(math.fabs(((c1 + c2 + c3) / 3)))
    sleep(10)

    # Use compass to send out panning messages
    # Check if button 'A' was pressed
    a = button_a.was_pressed()
    # If centre position is being selected - button 'A' was pressed
    if a is True:
        # Store button 'A' compass data to variable 'locate'
        locate = current_orien
        # Send through '1' to PD when button 'A' is pressed
        midiControlChange(0, 21, 1)
    # Reset centre position as '0' degree
    compass_degree = current_orien - locate
    # Reset compass degree ranging from 0 to 360
    if compass_degree < 0:
        compass_degree = compass_degree + 360
    # Set the centre degree as '90', Left as '0', Right as '180'
    compass_degree = compass_degree + 90
    if compass_degree > 360:
        compass_degree = compass_degree - 360
    sleep(10)
    # Send out massge when microbit is panning within left-to-right 180 degrees
    if 0 < compass_degree < 180:
        # Map 180 degrees to '127' so MIDI can send out the messages
        panning = math.floor(math.fabs(((compass_degree / 179) * 127)))
    # Send current panning messages to PD
    midiControlChange(0, 24, panning)
    sleep(10)

    # Use yaccelerometer as a sound source trigger
    # When microbit is tiled down to '-700', send out '1' to PD
    if current_y < -700:
        Strigger = 1
        midiControlChange(0, 23, Strigger)
    Strigger = 0
    sleep(10)

    # Use button 'B' as a Mode Switch / Stop / Reset button (More in PD)
    b = button_b.was_pressed()
    if b is True:
        midiControlChange(0, 22, 1)
    sleep(1)

    # Use extra button 'DistanceDialer' to control sound source distance (More in PD)
    c = pin1.is_touched()
    if c is True:
        midiNoteOn(0, 1, 127)
    # Make sure button only send out one message each time is pressed
    while pin1.is_touched():
        sleep(1)
